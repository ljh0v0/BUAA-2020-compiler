﻿#pragma once
#include <string>

using namespace std;

string int2string(int t);

int string2int(string s);

string getTempVar();

string getLabel();

string getStingLabel();